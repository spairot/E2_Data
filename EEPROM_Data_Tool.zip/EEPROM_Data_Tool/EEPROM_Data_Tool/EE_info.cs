﻿using System;

namespace EEPROM_Data_Tool
{
    public class EE_info
    {
        protected byte EECodeL;
        protected byte EECodeM;
        protected byte EECodeH;
    }

    public class EE_Code : EE_info
    {
        //public EE_Code(byte h, byte m, byte l) : base(h, m, l) { }
        public void setEECodeIndex(byte h, byte m, byte l)
        {
            EECodeH = h;
            EECodeM = m;
            EECodeL = l;
        }
        // Get EEPROM code
        public UInt32 getEECode()
        {
            UInt32 L_EECode = 0;

            if (EECodeH > IntelBuf.byteDataIntel.Length ||
                EECodeM > IntelBuf.byteDataIntel.Length ||
                EECodeL > IntelBuf.byteDataIntel.Length)
                return L_EECode;

            L_EECode = (UInt32)((IntelBuf.byteDataIntel[EECodeH] << 16) & 0x00FF0000);
            L_EECode |= (UInt32)((IntelBuf.byteDataIntel[EECodeM] << 8) & 0x0000FF00);
            L_EECode |= (UInt32)((IntelBuf.byteDataIntel[EECodeL]) & 0x000000FF);

            return L_EECode;
        }
    }
}

﻿/*
; #######################################################################
; # 																	#
; # Copyright(C) 2020 Toshiba Carrier Corporation.					    #
; # All Rights Reserved.												#
; # 																	#
; # The information contained herein is confidential property of		#
; # Toshiba Carrier Corporation. The user, copying, transfer or 		#
; # disclosure of such information is prohibited except by express		#
; # written agreement with Toshiba Carrier Corporation. 				#
; # 																	#
; # <Module name>														#
; # Main form															#
; # 																	#
; # <Module Description>												#
; # EE Tool main module           								        #
; # History 2020/05/20       First written	   S.Pairot          		#
; #######################################################################
*/
using Be.Windows.Forms;
using EEPROM_Data_Tool.Forms;
using MetroFramework.Components;
using System;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using DataTable = System.Data.DataTable;
using System.Text.RegularExpressions;

namespace EEPROM_Data_Tool
{
    public partial class FrmMain : Form
    {
        public static SettingData DataSet = new SettingData();
        string _fileName;
        UInt32 EECode;
        //string EEProjectName;
        byte DisplayFormat = 0;

        // field
        private Form activeForm;

        public FrmMain()
        {
            InitializeComponent();
            // Form
            this.Text = string.Empty;
            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.metroStyleManager = metroStyleManager1;
        }

        /// <summary>
        /// Panel MouseDown
        /// <param></param>
        /// Control drag form when mouse click and move on Top panel
        /// </summary>
        /// Method
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        /// <summary>
        /// Hide left menu control
        /// </summary>
        /// Method
        private void btnHideMenu_Click(object sender, EventArgs e)
        {
            if (pnlMenuLeft.Width == 140)
            {
                pnlMenuLeft.Width = 55;
                pnlLogo.Width = 55;
                pnlSubMenuTool.Left = 55;
                pnlSubMenuExport.Left = 55;
                hexBox.Left = 55;
                metroTabControl.Left = 55;
                //metroTabControl.Width = 890;
                btnNotification.Visible = false;
                btnEmail.Visible = false;
                lblcopyright.Visible = false;
                lbltctc.Visible = false;
            }
            else
            {
                pnlMenuLeft.Width = 140;
                pnlLogo.Width = 140;
                pnlSubMenuTool.Left = 140;
                pnlSubMenuExport.Left = 140;
                hexBox.Left = 140;
                metroTabControl.Left = 140;
                // metroTabControl.Width = 820;
                btnNotification.Visible = true;
                btnEmail.Visible = true;
                lblcopyright.Visible = true;
                lbltctc.Visible = true;
            }
        }


        #region LoadBackupData
        /// <summary>
        /// Read back up data from text file
        /// Reload previous user setting
        /// </summary>
        /// <param></param>
        private static string get_rom_setting(string getType)
        {
            string readLine, ret = null;
            //Search until reach the end point of message group
            try
            {
                string fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "BackupUserSetting.txt");
                StreamReader sr = new StreamReader(fileName);
                while ((readLine = sr.ReadLine()) != null)
                {
                    string[] elements = Regex.Split(readLine, ",");  // split the string
                    if (elements.Length > 1)                         // not empty array string
                    {
                        if (elements[0] == getType)
                        {
                            ret = elements[1];
                            break;
                        }
                    }
                }
                sr.Close();
            }
            catch (Exception) { };
            return ret;
        }
  
        /// <summary>
        /// Form start load
        /// </summary>
        /// <param></param>
        static void load_backup_setting()
        {
            string L_StrData = null;

            L_StrData = get_rom_setting("EditMode");  // Load edit mode setting
            if (L_StrData != null)
            {
                BackupData.EditEnable = Convert.ToBoolean(L_StrData);
                DataSet.EditEnable = BackupData.EditEnable;
            }

            L_StrData = get_rom_setting("Theme");    // Load theme
            if (L_StrData != null)
            {
                BackupData.ThemeColor = Convert.ToInt16(L_StrData);
                DataSet.ThemeColor = BackupData.ThemeColor;
            }

            L_StrData = get_rom_setting("Color");   // Load color
            if (L_StrData != null)
            {
                BackupData.DispColor = Convert.ToInt16(L_StrData);
                DataSet.DispColor = BackupData.DispColor;
            }
        }
        #endregion

        /// <summary>
        /// Back up user setting to RAM (Temporary)
        /// </summary>
        /// <param name="></param>
        private void backup_ram_setting(SettingData dt)
        {
            BackupData.EditEnable = dt.EditEnable;
            BackupData.ThemeColor = dt.ThemeColor;
            BackupData.DispColor = dt.DispColor;
        }

        #region SetControl
        /// <summary>
        /// Button menu hamburger click
        /// </summary>
        /// <param></param>
        private void set_user_control(String e_msg)
        {
            switch (e_msg)
            {
                case "FormLoad":
                    string UserName = Environment.UserName;
                    toolStriplblUser.Text = "User Name: " + UserName;
                    pnlSubMenuTool.Visible = false;  // Hide popup menu
                    pnlSubMenuExport.Visible = false; // Hide popup menu export
                    //btnExport.Enabled = false;
                    btnCloseChildForm.Visible = false;
                    //btnVerifyData.Enabled = false;
                    cboFile.Visible = false;
                    metroTabControl.SelectedIndex = 0;
                    metroStyleManager1.Style = MetroFramework.MetroColorStyle.Red;  // Metro UI color setting
                    SetTheme(BackupData.ThemeColor);                    // Set theme
                    SetDispColor(BackupData.DispColor);                 // Set color
                    break;
                case "Home":
                    lblTitle.Text = "Home";
                    if (activeForm != null)
                        activeForm.Close();
                    btnCloseChildForm.Visible = false;
                    metroTabControl.SelectedIndex = 0;
                    break;
                case "Setting":
                    lblTitle.Text = "Setting";
                    btnCloseChildForm.Visible = false;
                    break;
                case "Tool":
                    lblTitle.Text = "Tool";
                    break;
                case "Export":
                    lblTitle.Text = "Export";
                    break;
                case "Admin":
                    lblTitle.Text = "Admin";
                    break;
                case "OpenHex":
                    metroTabControl.SelectedIndex = 0;
                    //btnVerifyData.Enabled = true;
                    break;
                case "OpenTemplate":
                    metroTabControl.SelectedIndex = 1;
                    cboFile.Visible = true;
                    break;
                default:
                    break;
            }
        }
        #endregion

        /// <summary>
        /// Back up data to text file (ROM)
        /// </summary>
        /// <param></param>
        private void backup_rom_setting()
        {
            try
            {
                string fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "BackupUserSetting.txt");
                StreamWriter sw = new StreamWriter(fileName, false, Encoding.ASCII);

                sw.WriteLine("EditMode," + BackupData.EditEnable);        // Backup last edit mode setting
                sw.WriteLine("Theme," + BackupData.ThemeColor);           // Backup last theme setting
                sw.WriteLine("Color," + BackupData.DispColor);            // Backup last color setting

                sw.Close();
            }
            catch (Exception) { };
            return;
        }

        /// <summary>
        /// Form closing event
        /// </summary>
        /// <param></param>
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            backup_rom_setting();              // Backup user setting into ROM
        }

        /// <summary>
        /// Form load event
        /// </summary>
        /// <param></param>
        private void FrmMain_Load(object sender, EventArgs e)
        {
            pnlCursor.Height = btnHome.Height;
            pnlCursor.Top = btnHome.Top;
            pnlMenuLeft.Width = 55;
            pnlLogo.Width = 55;
            btnNotification.Visible = false;
            btnEmail.Visible = false;
            lblcopyright.Visible = false;
            lbltctc.Visible = false;

            pnlSubMenuTool.Left = 55;
            pnlSubMenuExport.Left = 55;  // set default location
            hexBox.Left = 55;
            metroTabControl.Left = 55;

            load_backup_setting();
            set_user_control("FormLoad");
        }

        /// <summary>
        /// Minimize application
        /// </summary>
        /// <param></param>
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        /// <summary>
        /// Maximize application
        /// </summary>
        /// <param></param>
        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }

        /// <summary>
        /// Close application
        /// </summary>
        /// <param></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Button Home click
        /// </summary>
        /// <param></param>
        private void btnHome_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnHome.Height;
            pnlCursor.Top = btnHome.Top;
            set_user_control("Home");
        }

        /// <summary>
        /// Setting theme
        /// </summary>
        /// <param></param>
        private void SetTheme(int theme)
        {
            switch(theme)
            {
                case 0:
                    metroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Light;
                    break;
                case 1:
                    metroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Dark;
                    break;
                default:
                    metroStyleManager1.Theme = MetroFramework.MetroThemeStyle.Default;
                    break;
            }
        }
        /// <summary>
        /// Setting display color
        /// </summary>
        /// <param></param>
        private void SetDispColor(int color)
        {
            metroStyleManager1.Style = (MetroFramework.MetroColorStyle)color;
        }

        /// <summary>
        /// Setting serial port
        /// </summary>
        /// <param></param>
        private void setting_data_update(DialogResult L_result, SettingData L_setting)
        {
            if (L_result == DialogResult.OK && L_setting != null)
            {

                DataSet.EditEnable = L_setting.EditEnable;       // Display scroll
                DataSet.ThemeColor = L_setting.ThemeColor;       // Display theme
                DataSet.DispColor = L_setting.DispColor;         // Display color
                SetTheme(DataSet.ThemeColor);                    // Set theme
                SetDispColor(DataSet.DispColor);                 // Set color
                backup_ram_setting(L_setting);                   // backup data
                set_user_control("Setting");
            }
        }
        /// <summary>
        /// Button Setting click
        /// </summary>
        /// <param></param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnSetting.Height;
            pnlCursor.Top = btnSetting.Top;

            FrmSetting Frm = new FrmSetting() { Setting = new SettingData() };
            OpenChildForm(Frm, sender);
            Frm.get_data_callback += setting_data_update;
        }
        /// <summary>
        /// Button Control click
        /// </summary>
        /// <param></param>
        private void btnTool_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnTool.Height;
            pnlCursor.Top = btnTool.Top;
            pnlSubMenuTool.Visible = true;  // Hide popup menu
            set_user_control("Tool");
        }
        /// <summary>
        /// Button Export click
        /// Save hex file
        /// </summary>
        /// <param></param>
        private void btnExport_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnExport.Height;
            pnlCursor.Top = btnExport.Top;
            pnlSubMenuExport.Visible = true;
            set_user_control("Export");
        }
        /// <summary>
        /// Button Admin click
        /// </summary>
        /// <param></param>
        private void btnAdmin_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnAdmin.Height;
            pnlCursor.Top = btnAdmin.Top;
            set_user_control("Admin");

            FrmLogin Frm = new FrmLogin() { };
            OpenChildForm(Frm, sender);
        }
        /// <summary>
        /// Button Logout click
        /// </summary>
        /// <param></param>
        private void btnLogout_Click(object sender, EventArgs e)
        {
            pnlCursor.Height = btnLogout.Height;
            pnlCursor.Top = btnLogout.Top;
            set_user_control("Logout");
            this.Close();
        }
        /// <summary>
        /// Mose hover on button control
        /// </summary>
        /// <param></param>
        private void btnTool_MouseHover(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = true;  // Show popup menu
        }
        /// <summary>
        /// Open Hex file
        /// 
        /// 
        /// 2020/05/25  First writtent  by S.Pairot
        /// </summary>
        private void btnOpenHex_Click(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = false;  // Hide popup menu
            OpenFile();                           // Open .hex file
            set_user_control("OpenHex");
        }

        #region LoadTemplate
        /// <summary>
        /// open template file
        /// </summary>
        /// <param></param>
        private void btnLoadTemplate_Click(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = false;  // Hide popup menu
            set_user_control("OpenTemplate");
            dataGridViewTmplate.DataSource = null;                  // Clear data grid view data source
            dataGridViewTmplate.Refresh();                          // refresh it
            try
            {
                using (OpenFileDialog ofd = new OpenFileDialog()                                             // use open file dialog
                { Filter = "Excel Files|*.xls;*.xlsx", ValidateNames = true })                               // set file filter
                {                                                                                            //
                    if (ofd.ShowDialog() == DialogResult.OK)                                                 // If click OK on open dialog popup window
                    {                                                                                        // use file stream control file access
                        OpenExcelFile(ofd.FileName);
                    }                                                                                        //
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Open excel file
        /// </summary>
        /// <param></param>
        OleDbConnection OleDbConn;
        private void OpenExcelFile(string FilePath)
        {
            try
            {
                string strConn = string.Empty;

                FileInfo file = new FileInfo(FilePath);
                if (!file.Exists) { throw new Exception("Error, File doesn't exist"); }

                string extension = file.Extension;
                switch (extension)
                {
                    case ".xls":
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                        break;
                    case ".xlsx":
                        strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1;'";
                        break;
                    default:
                        strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                        break;
                }
                OleDbConn = new OleDbConnection(strConn);
                OleDbConn.Open();

                // Get the data table containg the schema guid.
                DataTable dt = OleDbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                OleDbConn.Close();

                cboFile.Items.Clear();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // Add the sheet name to the string array.
                    string sheetName = dt.Rows[i]["TABLE_NAME"].ToString();
                    sheetName = sheetName.StartsWith("'") ? sheetName.Substring(1, sheetName.Length - 3) :
                                                            sheetName.Substring(0, sheetName.Length - 1);
                    cboFile.Items.Add(sheetName);
                }
                cboFile.SelectedIndex = 0;
                //txtPath.Text = FilePath;
                //UpdControl(CtrlEvent_t.OPEN_EXCEL_FILE);  // update control seting
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Change index in combobox file
        /// </summary>
        /// <param></param>
        private void cboFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            //dataGridViewCode.DataSource = result.Tables[cboFile.SelectedIndex];
            try
            {
                OleDbDataAdapter OleDbDa = new OleDbDataAdapter("Select * from [" + cboFile.Text + "$]", OleDbConn);
                DataTable dt = new DataTable();
                OleDbDa.Fill(dt);
                dataGridViewTmplate.DataSource = dt;
                //tabControl1.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Drag file into data grid view
        /// </summary>
        /// <param></param>
        private void dataGridViewTmplate_DragEnter(object sender, DragEventArgs e)
        {
            // Check if the Data format of the file(s) can be accepted
            // (we only accept file drops from Windows Explorer, etc.)
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // modify the drag drop effects to Move
                e.Effect = DragDropEffects.Move;
            }
            else
            {
                // no need for any drag drop effect
                e.Effect = DragDropEffects.None;
            }
        }

        /// <summary>
        /// Drop file into data grid view
        /// </summary>
        /// <param></param>
        private void dataGridViewTmplate_DragDrop(object sender, DragEventArgs e)
        {
            // still check if the associated data from the file(s) can be used for this purpose
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // Fetch the file(s) names with full path here to be processed
                string[] FileList = (string[])e.Data.GetData(DataFormats.FileDrop);
                // Your desired code goes here to process the file(s) being dropped
                OpenExcelFile(FileList[0]);
            }
        }
        #endregion

        #region VerifyData
        /// <summary>
        /// Start data verify
        /// Get verify result
        /// Payload data input
        /// Byte 0 = Index
        /// Byte 1 = Address Low
        /// Byte 2 = Address High
        /// Byte 3 = Access rule (Bit/Byte/Nibble)
        /// Byte 4 = Special Bit access Bit m - Bit n
        /// Byte 5 = Data for check
        /// 2020/24/05 S.Pairot  First written
        /// </summary>
        /// <param></param>
        private bool StartVerifyData(byte[] DtByte)
        {
            bool result = false;
            UInt16 L_address;
            byte L_data;
            ConvertData cv = new ConvertData();
            L_address = cv.Byte2UInt16(DtByte[2], DtByte[1]);      // convert to 2 bytes address
            if (L_address < IntelBuf.byteDataIntel.Length)         // Not over address range?
            {
                L_data = IntelBuf.byteDataIntel[L_address];        // get data
                if (DtByte[3] >= 0 && DtByte[3] <= 7)              // Bit access
                {
                    if (cv.ChkBit(L_data, DtByte[3]) == DtByte[5])  // Check bit data
                    {
                        result = true;                                // Verify OK
                    }
                }
                else if (DtByte[3] == 8)                           // Byte access
                {
                    if (L_data == DtByte[5])                       // Check byte data
                    {
                        result = true;                             // Verify OK
                    }
                }
                else if (DtByte[3] == 9)                           // Nibble High access
                {
                    if (cv.GetLowerUpperBit("Hi", L_data) == DtByte[5])
                    {
                        result = true;                             // Verify OK
                    }
                }
                else if (DtByte[3] == 10)                          // Nibble Low access
                {
                    if (cv.GetLowerUpperBit("Lo", L_data) == DtByte[5])
                    {
                        result = true;                             // Verify OK
                    }
                }
                else if (DtByte[3] == 11)                          // Bit m - Bit n
                {
                    byte Bn, Bm;
                    byte L_Dt0=0, L_Dt1=0;
                    byte j = 0;
                    Bm = cv.GetLowerUpperBit("Hi", DtByte[4]);    // Get Bit m
                    Bn = cv.GetLowerUpperBit("Lo", DtByte[4]);    // Get Bit n
                    for (byte i = Bm; i <= Bn; i++)               // Loop start from Bit m to Bit n
                    {
                        L_Dt0 = cv.ChkBit(L_data, i);             // Check data at bit m,...,n
                        L_Dt1 += (byte)(L_Dt0 << j);              // Dt * 2^n, n=0,1,2,...
                        j++;
                    }
                    if (L_Dt1 == DtByte[5])                       // Check final result
                    {
                        result = true;                             // Verify OK
                    }
                }
            }
            return (result);
        }

        /// <summary>
        /// GetDataToVerify
        /// Read data from data grid view table
        /// Prepare data for verify row by row
        /// 2020/24/05 S.Pairot  First written
        /// </summary>
        /// <param></param>
        private void GetDataToVerify()
        {
            ConvertData cv = new ConvertData();
            Access acc = new Access();
            byte[] data_buff = new byte[16];   // Input data bufer size 16 bytes
            byte[] temp_data;
            UInt16 row = 0;      // data grid view row
            UInt16 col = 0;      // data grid view column
            string chk_data = null;
            string strInput = null;
            string strAccess = null;
            bool result = false;

            do
            {
                try
                {
                    var value = dataGridViewTmplate.Rows[row].Cells[col].Value;      // get value from data grid cell
                    if (value != null) chk_data = value.ToString();                  // Convert value to string when value not null
                    else chk_data = null;                                            // Null value
                    if (string.IsNullOrEmpty(chk_data)) { break; }                   // exit loop when data read end line or overflow

                    strInput = value.ToString();                                     // Get verify number
                    temp_data = cv.HexToByte(strInput);                              // convert string data to dec
                    data_buff[0] = temp_data[0];

                    col = 1;                        // Verify permission
                    strInput = dataGridViewTmplate.Rows[row].Cells[col].Value.ToString();
                    if (strInput == "YES" || strInput == "Yes" || strInput == "yes")   // verify items enable
                    {
                        col = 4;                    // Address LOW
                        strInput = dataGridViewTmplate.Rows[row].Cells[col].Value.ToString();  // Get address low
                        temp_data = cv.HexToByte(strInput);                   // convert hex data to dec
                        data_buff[1] = temp_data[0];                         // Copy data converted to buffer

                        col++;                     // Address HIGH
                        strInput = dataGridViewTmplate.Rows[row].Cells[col].Value.ToString();  // Get address high
                        temp_data = cv.HexToByte(strInput);                   // convert hex data to dec
                        data_buff[2] = temp_data[0];                         // Copy data converted to buffer

                        col++;                     // Access data rule (bit/byte/nibble)
                        strAccess = dataGridViewTmplate.Rows[row].Cells[col].Value.ToString();  // Get address low
                        foreach (string str in acc.Rule)
                        {
                            data_buff[3] = 11;   // Default access rule is Bit m - Bit n
                            if (str == strAccess)
                            {
                                data_buff[3] = Convert.ToByte(Array.IndexOf(acc.Rule, str));
                                break;
                            }
                        }
                        if (data_buff[3] == 11) // access rule is Bit m - Bit n
                        { 
                            // Example "BIT24", Substring to "24" it's mean start from bit 2, end bit 4
                            strAccess = strAccess.Substring(strAccess.IndexOf('T')+1, 2); // Get only bit number
                            temp_data = cv.HexToByte(strAccess);  // Convert string to byte
                            data_buff[4] = temp_data[0];          // Bit location
                        }

                        col++;                 // Data check, data reference for confirm
                        strInput = dataGridViewTmplate.Rows[row].Cells[col].Value.ToString();  // Get data for check
                        temp_data = cv.HexToByte(strInput);                   // convert hex data to dec
                        data_buff[5] = temp_data[0];                         // Copy data converted to buffer

                        result = StartVerifyData(data_buff);  // Verify data
                        if (result == true)                   // Mark green color
                        {
                            this.dataGridViewTmplate.Rows[row].Cells[col].Style.BackColor = Color.FromArgb(192, 255, 192);  // Green
                        }
                        else                                 // Mark red color
                        {
                            this.dataGridViewTmplate.Rows[row].Cells[col].Style.BackColor = Color.FromArgb(255, 128, 128);  // Red
                        }
                        col = 0;             // Reset column index
                        row++;               // Go to next row
                    }
                    else                     // Verify item disable/skip
                    {                        // Skip verify item
                        col = 0;             // Reset column index
                        row++;               // Go to next row data
                    }
                }
                catch (Exception ex) {       // In case of error occur
                    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            while (row < (dataGridViewTmplate.Rows.Count)); // End row check
        }
        #endregion

        /// <summary>
        /// Start verify data
        /// </summary>
        /// <param></param>
        private void btnVerifyData_Click(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = false;  // Hide popup menu
            metroTabControl.SelectedIndex = 1;  // Set tab control display
            if (dataGridViewTmplate.DataSource != null && IntelBuf.byteDataIntel != null) {  // not null template data
                GetDataToVerify();  // Get data from template
            }
            else
            {   // Error
                MessageBox.Show("No template/hex data", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Reset highligh color in check result column
        /// </summary>
        /// <param></param>
        private void btnResetResult_Click(object sender, EventArgs e)
        {
            UInt16 row = 0;      // data grid view row
            UInt16 col = 0;      // data grid view column
            if (dataGridViewTmplate.DataSource != null)  // Not null data
            {
                for (UInt16 i = 0; i < dataGridViewTmplate.ColumnCount; i++)   // loop for find verify result column index
                {
                    if (dataGridViewTmplate.Columns[i].HeaderText == "Check")  // Find column
                    {
                        col = i;
                        break;
                    }
                }
                // Loop for clear hightlight color
                do
                {
                    this.dataGridViewTmplate.Rows[row].Cells[col].Style.BackColor = Color.White;  // Reset highlight color to white
                } while (++row < dataGridViewTmplate.Rows.Count);
            }
        }

        /// <summary>
        /// Button home mouse hover
        /// </summary>
        /// <param></param>
        private void btnHome_MouseHover(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = false;  // Hide sub menu tool
            pnlSubMenuExport.Visible = false;  // Hide submenu export
        }

        #region OpenHex
        /// <summary>
        /// Enables drag&drop
        /// </summary>
        private void hexBox_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }
        /// <summary>
        /// Processes a file drop
        /// </summary>
        private void hexBox_DragDrop(object sender, DragEventArgs e)
        {
            object oFileNames = e.Data.GetData(DataFormats.FileDrop);
            string[] fileNames = (string[])oFileNames;
            if (fileNames.Length == 1)
            {
                OpenFile(fileNames[0], DisplayFormat);
            }
        }
        /// <summary>
        /// Open hex file
        /// </summary>
        void OpenFile()
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                OpenFile(openFileDialog.FileName, DisplayFormat);
            }
        }

        /// <summary>
        /// Opens a file. (Overload function)
        /// </summary>
        /// <param name="fileName">the file name of the file to open</param>
        public void OpenFile(string fileName, int DisplayFormat)
        {
            if (!File.Exists(fileName))
            {
                MessageBox.Show("File does not exist", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (CloseFile() == DialogResult.Cancel)
                return;

            try
            {
                DynamicFileByteProvider dynamicFileByteProvider;
                try
                {
                    // try to open in write mode
                    dynamicFileByteProvider = new DynamicFileByteProvider(fileName);
                    dynamicFileByteProvider.Changed += new EventHandler(byteProvider_Changed);
                    dynamicFileByteProvider.LengthChanged += new EventHandler(byteProvider_LengthChanged);
                }
                catch (IOException) // write mode failed
                {
                    try
                    {
                        // try to open in read-only mode
                        dynamicFileByteProvider = new DynamicFileByteProvider(fileName, true);
                        if (DialogResult.No == MessageBox.Show("Open read only file?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Information))
                        {
                            dynamicFileByteProvider.Dispose();
                            return;
                        }
                    }
                    catch (IOException) // read-only also failed
                    {
                        // file cannot be opened
                        MessageBox.Show("Open file failed", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                IntelBuf.byteDataIntel = new byte[dynamicFileByteProvider.Length];   // Create dynamic array length

                //hexBox.ByteProvider = dynamicFileByteProvider;                 // Send to object
                if (DisplayFormat == 0)  // Intel hex format
                {
                    if (ConvertFromIntelHexFormat(dynamicFileByteProvider))     // Convert to Intel hex format
                    {
                        DynamicByteProvider dm = new DynamicByteProvider(IntelBuf.byteDataIntel); // create new dynamic byte provider object
                        hexBox.ByteProvider = dm;                               // send to hex box
                        hexBox.Invalidate();                                    // update current
                        dynamicFileByteProvider.Dispose();                      // Destroy current object
                    }
                }
                else                                                            // ANSI
                {
                    hexBox.ByteProvider = dynamicFileByteProvider;              // Send to object
                }

                _fileName = fileName;

                DisplayText();

                UpdateFileSizeStatus();

                //RecentFileHandler.AddFile(fileName);

                UpdateEEInfo();                                                  // Update EEPROM information 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                ManageAbility();
            }
        }
        /// <summary>
        /// Convert to Intel hex format 
        /// input Dynamic file byte provider
        /// Output bool result true/false = convert sucess/fail
        /// 2019/03/25  First written  by S.Pairot
        /// </summary>
        bool ConvertFromIntelHexFormat(DynamicFileByteProvider In_dynaFile)
        {
            int V_PageLength = 43;                                       // Intel packet length per line
            byte V_IntelStartCode = 0x3A;                                // Usually start code :

            byte[] byteData = new byte[V_PageLength + 7];                // Byte data buffer + offset
            byte[] TempByteDataIntel = new byte[V_PageLength + 7];
            byte L_ByteCount = 0;
            string strDataInput;
            byte L_len = 0;
            byte L_lenCount = 0;
            string L_strTemp = null;
            char[] chrTemp = null;
            int L_intData = 0;
            int L_pageData = 0;
            int L_TransferCount = 0;
            bool result = false;
            IntelHexFormat intelHex = new IntelHexFormat();
            dec_state = DecodeState.Idle;

            for (long i = 0; i < In_dynaFile.Length; i++)                // Loop until dynamic reach the dynamic file length
            {
                byteData[L_ByteCount] = In_dynaFile.ReadByte(i);         // Copy to local byte buffer

                if (dec_state == DecodeState.Idle)                       // Decode intel hex state proceed
                {                                                        //
                    if (byteData[L_ByteCount] == V_IntelStartCode)       // Intel hext format start code <:>
                    {
                        L_len = GetIntelPacketLen(IntelPack.ByteCount);  // Get intel hex byte count
                        chrTemp = new char[L_len];                       // Assign length to array object
                        dec_state = DecodeState.ChkLength;               // set check length state
                        ++L_ByteCount;                                   // Increment byte count
                    }
                }
                else if (dec_state == DecodeState.ChkLength)             // Intel hext format byte count (1 byte)
                {
                    chrTemp[L_lenCount] = Convert.ToChar(byteData[L_ByteCount]);  // Convert byte to char
                    L_strTemp += chrTemp[L_lenCount].ToString();         // Combine char to string

                    if (++L_lenCount >= L_len)                           // end of byte count
                    {                                                    // local length count
                        L_intData = int.Parse(L_strTemp, System.Globalization.NumberStyles.HexNumber);  // Convert string to hex
                        L_lenCount = 0;                                  // reset length count
                        L_strTemp = "";                                  // clear string

                        if (L_intData > 0)                               // Length not zero
                            dec_state = DecodeState.DataStore;           // Set copy data state
                        else                                             // No data
                        {
                            break;                                       // Exit
                        }
                    }
                    ++L_ByteCount;                                       // Increment byte count
                }
                else if (dec_state == DecodeState.DataStore)             // Copy data state
                {
                    if (++L_ByteCount >= V_PageLength)                   // reach last element            
                    {
                        strDataInput = ASCIIEncoding.ASCII.GetString(byteData); // Convert byte array to ascii string [3A],[31],[30],... => ":10"
                        TempByteDataIntel = intelHex.Deserialize(strDataInput); // Decode to intel hex format
                                                                                // :10000000E20BD4C1011922BF5EEB30220000302286 => E20BD4C1011922BF5EEB302200003022
                        for (L_TransferCount = 0; L_TransferCount < TempByteDataIntel.Length; L_TransferCount++)
                        {
                            IntelBuf.byteDataIntel[L_pageData + L_TransferCount] = TempByteDataIntel[L_TransferCount];  // Transfer data to next buffer
                        }
                        L_pageData += TempByteDataIntel.Length;         // increment page data
                        L_ByteCount = 0;                                // reset byte count  
                        result = true;                                  // Set result true
                        Array.Clear(byteData, 0, byteData.Length);      // clear
                        dec_state = DecodeState.Idle;                   // reset state
                    }
                }
            }
            return (result);
        }

        /// <summary>
        /// Closes the current file
        /// </summary>
        /// <returns>OK, if the current file was closed.</returns>
        DialogResult CloseFile()
        {
            if (hexBox.ByteProvider == null)
                return DialogResult.OK;

            try
            {
                if (hexBox.ByteProvider != null && hexBox.ByteProvider.HasChanges())
                {
                    DialogResult res = MessageBox.Show("Save change?",
                            "Message",
                            MessageBoxButtons.YesNoCancel,
                            MessageBoxIcon.Warning);
                    if (res == DialogResult.Yes)
                    {
                        SaveFile();
                        CleanUp();
                    }
                    else if (res == DialogResult.No)
                    {
                        CleanUp();
                    }
                    else if (res == DialogResult.Cancel)
                    {
                        return res;
                    }

                    return res;

                }
                else
                {
                    CleanUp();
                    return DialogResult.OK;
                }
            }
            finally
            {
                ManageAbility();
            }
        }
        void CleanUp()
        {
            if (hexBox.ByteProvider != null)
            {
                IDisposable byteProvider = hexBox.ByteProvider as IDisposable;
                if (byteProvider != null)
                    byteProvider.Dispose();
                hexBox.ByteProvider = null;
            }
            _fileName = null;
            DisplayText();
        }

        void byteProvider_Changed(object sender, EventArgs e)
        {
            ManageAbility();
        }

        void byteProvider_LengthChanged(object sender, EventArgs e)
        {
            UpdateFileSizeStatus();
        }

        /// <summary>
        /// Manages enabling or disabling of menu items and toolstrip buttons.
        /// </summary>
        void ManageAbility()
        {
            if (hexBox.ByteProvider == null)
            {
                //cmbHexFormat.Enabled = false;
                //btnExport.Enabled = false;
            }
            else
            {
                //cmbHexFormat.Enabled = true;

                //if (BackupData.EditEnable) btnExport.Enabled = true;  // Edit mode allowance
                //else btnExport.Enabled = false;
                //btnExport.Enabled = true;
            }
        }

        /// <summary>
        /// Updates the File size status label
        /// </summary>
        void UpdateFileSizeStatus()
        {
            if (this.hexBox.ByteProvider == null)
                this.fileSizeToolStripStatusLabel.Text = string.Empty;
            else
                this.fileSizeToolStripStatusLabel.Text = Utility.GetDisplayBytes(this.hexBox.ByteProvider.Length);
        }

        /// <summary>
        /// Displays the file name in the Formดs text property
        /// </summary>
        /// <param name="fileName">the file name to display</param>
        void DisplayText()
        {
            /*
                if (_fileName != null && _fileName.Length > 0)
                {
                    string textFormat = "{0}{1} - {2}";
                    string readOnly = ((DynamicFileByteProvider)hexBox.ByteProvider).ReadOnly
                               ? strings.Readonly : "";
                        string text = Path.GetFileName(_fileName);
                        this.Text = string.Format(textFormat, text, readOnly, Program.SoftwareName);
                }
                else
                {
                   this.Text = Program.SoftwareName;
                }
            */
        }

        /// <summary>
        /// Hex box mouse click down
        /// </summary>
        /// <param name="></param>
        private void Position_Changed(object sender, EventArgs e)
        {
            this.ToolStripStatusLabel.Text = string.Format("Line {0}   Col {1} ",
               hexBox.CurrentLine, hexBox.CurrentPositionInLine);

            string bitPresentation = string.Empty;

            byte? currentByte = hexBox.ByteProvider != null && hexBox.ByteProvider.Length > hexBox.SelectionStart
                ? hexBox.ByteProvider.ReadByte(hexBox.SelectionStart)
                : (byte?)null;

            BitInfo bitInfo = currentByte != null ? new BitInfo((byte)currentByte, hexBox.SelectionStart) : null;

            if (bitInfo != null)
            {
                byte currentByteNotNull = (byte)currentByte;
                bitPresentation = string.Format(" Bits of Byte {0}: {1}"
                    , hexBox.SelectionStart
                    , bitInfo.ToString()
                    );
            }
            this.bitToolStripStatusLabel.Text = bitPresentation;
            //this.bitControl1.BitInfo = bitInfo;
        }

        /// <summary>
        /// Update model information
        /// <param name="></param>
        /// input : None
        /// output : None
        /// 2019-03-27      First written by S.Pairot
        private void UpdateEEInfo()
        {
            string strEE = "";
             EE_Code ee = new EE_Code();
             ee.setEECodeIndex(3, 2, 1);              // Set EEPROM code index byte H=3, M=2, L=1
             EECode = ee.getEECode();                 // Get EEPROM code
            //EEProjectName = GetProjectName(EECode);  // use EEPROM code to find project name
            //txtProjectName.Text = EEProjectName;     // dispaly project name
            //ConfigModelTable(EEProjectName);         // use project name config model table
            strEE = EECode.ToString("X");              // Cut 0x
            if (strEE.Length < 6) strEE = "0" + strEE; // Inser 0 before EEPROM code 12530 => 012530
            toolStripStatusLabelEECode.Text = "EEPROM: " + strEE;
        }

        enum DecodeState
        {
            Idle = 0,
            ChkLength,
            DataStore,
            WriteDataBack,
        };
        DecodeState dec_state = new DecodeState();

        private enum IntelPack
        {
            StartCode = 0,
            ByteCount,
            Address,
            RecordType,
            Data,
            CheckSum,
        };

        /*[row,column]*/
        /*Packet name,  digit */
        byte[,] intelPacket = new byte[,]
        {
            { (byte)IntelPack.StartCode,    1},  // Start Code     1 digit
            { (byte)IntelPack.ByteCount,    2},  // Byte count     2 digit
            { (byte)IntelPack.Address,      4},  // Address        4 digit
            { (byte)IntelPack.RecordType,   2},  // Record type    2 digit
            { (byte)IntelPack.Data,         0},  // Data           n digit
            { (byte)IntelPack.CheckSum,     2},  // Check sum      2 digit
        };
        private MetroStyleManager metroStyleManager;

        /// <summary>
        /// Get intel packet length
        /// input intel packet name
        /// Output None
        /// 2019/03/25  First writtent  by S.Pairot
        /// </summary>
        byte GetIntelPacketLen(IntelPack p)
        {
            byte L_len = 0;
            for (byte row = 0; row < intelPacket.Length / 2; row++)
            {
                if (intelPacket[row, 0] == (byte)p)   // input name equal intel packet table?
                {
                    L_len = intelPacket[row, 1];      // return digit length
                    break;                            // Exit loop
                }
            }
            return L_len;                             // return result
        }

        /// <summary>
        /// Select hex display format "ANSI"
        /// input None
        /// Output None
        /// 2020/05/25  First writtent  by S.Pairot
        /// </summary>
        private void aNSIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStripDropDownButton.Text = "ANSI";
            DisplayFormat = 1;
            OpenFile(_fileName, DisplayFormat);
        }

        /// <summary>
        /// Select hex display format "INTEL"
        /// input None
        /// Output None
        /// 2020/05/25  First writtent  by S.Pairot
        /// </summary>
        private void iNTELToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStripDropDownButton.Text = "INTEL";
            DisplayFormat = 0;
            OpenFile(_fileName, DisplayFormat);
        }
        #endregion

        /// <summary>
        /// Saves the current file.
        /// Save hex file
        /// </summary>
        void SaveFile()
        {
            if (hexBox.ByteProvider == null)  // null data or disable edit mode
            {
                MessageBox.Show("No hex data", "Message",
                       MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (BackupData.EditEnable == false)  // disable edit mode
            {
                MessageBox.Show("Edit mode disabled", "Message",
                       MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            try
            {
                DynamicFileByteProvider dynamicFileByteProvider = hexBox.ByteProvider as DynamicFileByteProvider;
                dynamicFileByteProvider.ApplyChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ManageAbility();
            }
        }

        /// <summary>
        /// Ckeck wheter string array is null or empty
        /// input string array
        /// 1/0 = null/not null
        /// 2020/05/25  First writtent  by S.Pairot
        /// </summary>
        static bool IsNullOrEmpty<T>(T[] myStringArray)
        {
            return (myStringArray == null || myStringArray.Length < 1);
        }

        /// <summary>
        /// Notification message
        /// </summary>
        /// <param></param>
        private void btnNotification_Click(object sender, EventArgs e)
        {
            string ReleaseHistory = "";
            ReleaseHistory = "EETool V1.0\n";
            ReleaseHistory += "Release data : 30-May-2020\n";
            ReleaseHistory += "Change point : First Making\n";
            ReleaseHistory += "Author : Pairot S.\n";
            MessageBox.Show(ReleaseHistory, "Version information",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Mailbox
        /// </summary>
        /// <param></param>
        private void btnEmail_Click(object sender, EventArgs e)
        {
            string ContactInfo = "";
            ContactInfo = "Pairot Sukhirun\n";
            ContactInfo += "Software Design Engineer\n";
            ContactInfo += "Toshiba Carrier (Thailand)\n";
            ContactInfo += "Email: pairot.sukhirun@tctc.co.jp\n";
            MessageBox.Show(ContactInfo, "Contact information",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Open Child Form
        /// </summary>
        /// <param></param>
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.pnlContainer.Controls.Add(childForm);
            this.pnlContainer.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
            btnCloseChildForm.Visible = true;
        }

        /// <summary>
        /// Close sub form
        /// </summary>
        /// <param></param>
        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            btnCloseChildForm.Visible = false;
        }

        /// <summary>
        /// Change tab control
        /// </summary>
        /// <param></param>
        private void metroTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (metroTabControl.SelectedIndex == 1) {
                cboFile.Visible = true;
            }
            else
            {
                cboFile.Visible = false;
            }
        }

        #region Export data
        /// <summary>
        /// Export data main menu
        /// </summary>
        /// <param></param>
        private void btnExport_MouseHover(object sender, EventArgs e)
        {
            pnlSubMenuTool.Visible = false;  // Hide popup menu
            pnlSubMenuExport.Visible = true;  // Show sub menu export
            pnlSubMenuExport.Top = btnExport.Top;
        }

        /// <summary>
        /// Export hex
        /// </summary>
        /// <param></param>
        private void btnExportHex_Click(object sender, EventArgs e)
        {
            pnlSubMenuExport.Visible = false;  // Hide sub menu export
            SaveFile();
        }


        /// <summary>
        /// Export excel
        /// </summary>
        /// <param></param>
        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            pnlSubMenuExport.Visible = false;  // Hide sub menu export
            if (dataGridViewTmplate.DataSource != null)
            {
                ExportToExcel();   // Save template file
            }
            else
            {
                MessageBox.Show("No excel template", "Message",
                  MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /*
        Function : ExportToExcel
        Detail   : Save current excel file
        Input    : None
        Output   : None
        History  : 2018-11-13 First written by S.Pairot
        */
        private void ExportToExcel()
        {
            // Creating a Excel object. 
            _Application excel = new Microsoft.Office.Interop.Excel.Application();
            _Workbook workbook = excel.Workbooks.Add(Type.Missing);
            _Worksheet worksheet = null;

            try
            {

                worksheet = workbook.ActiveSheet;

                worksheet.Name = "Sheet1";

                int cellRowIndex = 1;
                int cellColumnIndex = 1;

                //Loop through each row and read value from each column. 
                for (int i = 0; i < dataGridViewTmplate.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridViewTmplate.Columns.Count; j++)
                    {
                        // Excel index starts from 1,1. As first Row would have the Column headers, adding a condition check. 
                        if (cellRowIndex == 1)
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridViewTmplate.Columns[j].HeaderText;
                        }
                        else
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridViewTmplate.Rows[i - 1].Cells[j].Value.ToString();
                        }
                        cellColumnIndex++;
                    }
                    cellColumnIndex = 1;
                    cellRowIndex++;
                }

                //Getting the location and file name of the excel to save from user. 
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 2;

                if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    MessageBox.Show("Save file Successful", "Save Status",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Can't save file!!!" + "\n" + ex.Message, "Save Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                excel.Quit();
                workbook = null;
                excel = null;
            }

        }

        #endregion


        //EOF
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EEPROM_Data_Tool.Forms
{
    public partial class FrmSetting : Form
    {
        public SettingData Setting { get; set; }               // Serial boject class (from SerialPortSetting.cs)
        private DialogResult L_result;
        public delegate void callback_data(DialogResult result, SettingData setting);
        public event callback_data get_data_callback;

        public FrmSetting()
        {
            InitializeComponent();
            
        }

        /// <summary>
        /// Form setting load
        /// </summary>
        /// <param name="></param>
        private void FrmSetting_Load(object sender, EventArgs e)
        {
            if (BackupData.EditEnable == true) chkBoxEditEn.Checked = true;
            else chkBoxEditEn.Checked = false;

            if (BackupData.ThemeColor > 0) cmbTheme.SelectedIndex = BackupData.ThemeColor;
            else cmbTheme.SelectedIndex = 0;
            ChangeTheme(cmbTheme.SelectedIndex);

            if (BackupData.DispColor > 0) cmbDispColor.SelectedIndex = BackupData.DispColor;
            else cmbDispColor.SelectedIndex = 0;
        }

        /// <summary>
        /// Click OK button
        /// </summary>
        /// <param name="></param>
        private void btnSettingOK_Click(object sender, EventArgs e)
        {
            Setting.EditEnable = chkBoxEditEn.Checked;                    // get edit mode en/dis
            Setting.ThemeColor = cmbTheme.SelectedIndex;                  // get theme color
            Setting.DispColor  = cmbDispColor.SelectedIndex;              // get display color
            L_result = DialogResult.OK;                                   // set dialog result OK
            get_data_callback(L_result, Setting);
            this.Close();
        }

        /// <summary>
        /// Click Cancel button
        /// </summary>
        /// <param name="></param>
        private void btnSettingCancel_Click(object sender, EventArgs e)
        {
            L_result = DialogResult.Cancel;              // set dialog result OK
            get_data_callback(L_result, null);
            this.Close();
        }


        /// <summary>
        /// Display theme
        /// </summary>
        /// <param name="></param>
        private void ChangeTheme(int theme)
        {
            switch (theme)
            {
                case 0:
                    cmbTheme.BackColor = Color.White;
                    cmbTheme.ForeColor = Color.Black;
                    break;
                case 1:
                    cmbTheme.BackColor = Color.Black;
                    cmbTheme.ForeColor = Color.White;
                    break;
                default:
                    cmbTheme.BackColor = Color.White;
                    cmbTheme.ForeColor = Color.Black;
                    break;
            }
        }

        /// <summary>
        /// Select theme
        /// </summary>
        /// <param name="></param>
        private void cmbTheme_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeTheme(cmbTheme.SelectedIndex);
        }

        //EOF
    }
}

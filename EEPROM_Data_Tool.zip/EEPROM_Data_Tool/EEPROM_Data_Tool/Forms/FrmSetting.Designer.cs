﻿namespace EEPROM_Data_Tool.Forms
{
    partial class FrmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSetting));
            this.groupBoxDisplay = new System.Windows.Forms.GroupBox();
            this.btnRefreshComport = new System.Windows.Forms.Button();
            this.cmbDispColor = new System.Windows.Forms.ComboBox();
            this.cmbTheme = new System.Windows.Forms.ComboBox();
            this.lblColor = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblTheme = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.groupBoxEdit = new System.Windows.Forms.GroupBox();
            this.chkBoxEditEn = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSettingOK = new System.Windows.Forms.Button();
            this.btnSettingCancel = new System.Windows.Forms.Button();
            this.groupBoxDisplay.SuspendLayout();
            this.groupBoxEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxDisplay
            // 
            this.groupBoxDisplay.Controls.Add(this.btnRefreshComport);
            this.groupBoxDisplay.Controls.Add(this.cmbDispColor);
            this.groupBoxDisplay.Controls.Add(this.cmbTheme);
            this.groupBoxDisplay.Controls.Add(this.lblColor);
            this.groupBoxDisplay.Controls.Add(this.lblTheme);
            this.groupBoxDisplay.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.groupBoxDisplay.Location = new System.Drawing.Point(87, 98);
            this.groupBoxDisplay.Name = "groupBoxDisplay";
            this.groupBoxDisplay.Size = new System.Drawing.Size(342, 171);
            this.groupBoxDisplay.TabIndex = 1;
            this.groupBoxDisplay.TabStop = false;
            this.groupBoxDisplay.Text = "Display";
            // 
            // btnRefreshComport
            // 
            this.btnRefreshComport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefreshComport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefreshComport.FlatAppearance.BorderSize = 0;
            this.btnRefreshComport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshComport.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshComport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.btnRefreshComport.Image = ((System.Drawing.Image)(resources.GetObject("btnRefreshComport.Image")));
            this.btnRefreshComport.Location = new System.Drawing.Point(288, -44);
            this.btnRefreshComport.Name = "btnRefreshComport";
            this.btnRefreshComport.Size = new System.Drawing.Size(40, 30);
            this.btnRefreshComport.TabIndex = 4;
            this.btnRefreshComport.UseVisualStyleBackColor = true;
            // 
            // cmbDispColor
            // 
            this.cmbDispColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.cmbDispColor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbDispColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDispColor.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDispColor.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbDispColor.FormattingEnabled = true;
            this.cmbDispColor.Items.AddRange(new object[] {
            "Default",
            "Black",
            "White",
            "Silver",
            "Blue",
            "Green",
            "Lime",
            "Teal",
            "Orange",
            "Brown",
            "Pink",
            "Magenta",
            "Purple",
            "Red",
            "Yellow"});
            this.cmbDispColor.Location = new System.Drawing.Point(125, 86);
            this.cmbDispColor.Margin = new System.Windows.Forms.Padding(4);
            this.cmbDispColor.Name = "cmbDispColor";
            this.cmbDispColor.Size = new System.Drawing.Size(150, 28);
            this.cmbDispColor.TabIndex = 2;
            // 
            // cmbTheme
            // 
            this.cmbTheme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.cmbTheme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbTheme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTheme.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTheme.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbTheme.FormattingEnabled = true;
            this.cmbTheme.Items.AddRange(new object[] {
            "Light",
            "Dark"});
            this.cmbTheme.Location = new System.Drawing.Point(125, 49);
            this.cmbTheme.Margin = new System.Windows.Forms.Padding(4);
            this.cmbTheme.Name = "cmbTheme";
            this.cmbTheme.Size = new System.Drawing.Size(150, 28);
            this.cmbTheme.TabIndex = 1;
            this.cmbTheme.Text = "Light";
            this.cmbTheme.SelectedIndexChanged += new System.EventHandler(this.cmbTheme_SelectedIndexChanged);
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.lblColor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblColor.Location = new System.Drawing.Point(12, 89);
            this.lblColor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(64, 21);
            this.lblColor.TabIndex = 0;
            this.lblColor.Text = "Color :";
            // 
            // lblTheme
            // 
            this.lblTheme.AutoSize = true;
            this.lblTheme.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTheme.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.lblTheme.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTheme.Location = new System.Drawing.Point(12, 52);
            this.lblTheme.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTheme.Name = "lblTheme";
            this.lblTheme.Size = new System.Drawing.Size(75, 21);
            this.lblTheme.TabIndex = 0;
            this.lblTheme.Text = "Theme :";
            // 
            // groupBoxEdit
            // 
            this.groupBoxEdit.Controls.Add(this.chkBoxEditEn);
            this.groupBoxEdit.Controls.Add(this.button1);
            this.groupBoxEdit.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.groupBoxEdit.Location = new System.Drawing.Point(436, 98);
            this.groupBoxEdit.Name = "groupBoxEdit";
            this.groupBoxEdit.Size = new System.Drawing.Size(342, 171);
            this.groupBoxEdit.TabIndex = 2;
            this.groupBoxEdit.TabStop = false;
            this.groupBoxEdit.Text = "Edit";
            // 
            // chkBoxEditEn
            // 
            this.chkBoxEditEn.AutoSize = true;
            this.chkBoxEditEn.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.chkBoxEditEn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.chkBoxEditEn.Location = new System.Drawing.Point(25, 47);
            this.chkBoxEditEn.Name = "chkBoxEditEn";
            this.chkBoxEditEn.Size = new System.Drawing.Size(193, 25);
            this.chkBoxEditEn.TabIndex = 5;
            this.chkBoxEditEn.Text = "Edit mode enabled";
            this.chkBoxEditEn.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(91)))), ((int)(((byte)(161)))));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(288, -44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 30);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnSettingOK
            // 
            this.btnSettingOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettingOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.btnSettingOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingOK.FlatAppearance.BorderSize = 0;
            this.btnSettingOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettingOK.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingOK.ForeColor = System.Drawing.Color.White;
            this.btnSettingOK.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingOK.Image")));
            this.btnSettingOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingOK.Location = new System.Drawing.Point(601, 401);
            this.btnSettingOK.Name = "btnSettingOK";
            this.btnSettingOK.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSettingOK.Size = new System.Drawing.Size(140, 50);
            this.btnSettingOK.TabIndex = 4;
            this.btnSettingOK.Text = "      OK";
            this.btnSettingOK.UseVisualStyleBackColor = false;
            this.btnSettingOK.Click += new System.EventHandler(this.btnSettingOK_Click);
            // 
            // btnSettingCancel
            // 
            this.btnSettingCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSettingCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.btnSettingCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSettingCancel.FlatAppearance.BorderSize = 0;
            this.btnSettingCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettingCancel.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettingCancel.ForeColor = System.Drawing.Color.White;
            this.btnSettingCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnSettingCancel.Image")));
            this.btnSettingCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSettingCancel.Location = new System.Drawing.Point(438, 401);
            this.btnSettingCancel.Name = "btnSettingCancel";
            this.btnSettingCancel.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSettingCancel.Size = new System.Drawing.Size(150, 50);
            this.btnSettingCancel.TabIndex = 3;
            this.btnSettingCancel.Text = "      Cancel";
            this.btnSettingCancel.UseVisualStyleBackColor = false;
            this.btnSettingCancel.Click += new System.EventHandler(this.btnSettingCancel_Click);
            // 
            // FrmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(808, 513);
            this.Controls.Add(this.btnSettingOK);
            this.Controls.Add(this.btnSettingCancel);
            this.Controls.Add(this.groupBoxEdit);
            this.Controls.Add(this.groupBoxDisplay);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSetting";
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.FrmSetting_Load);
            this.groupBoxDisplay.ResumeLayout(false);
            this.groupBoxDisplay.PerformLayout();
            this.groupBoxEdit.ResumeLayout(false);
            this.groupBoxEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDisplay;
        private System.Windows.Forms.Button btnRefreshComport;
        private System.Windows.Forms.ComboBox cmbDispColor;
        private System.Windows.Forms.ComboBox cmbTheme;
        private Bunifu.Framework.UI.BunifuCustomLabel lblColor;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTheme;
        private System.Windows.Forms.GroupBox groupBoxEdit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chkBoxEditEn;
        private System.Windows.Forms.Button btnSettingOK;
        private System.Windows.Forms.Button btnSettingCancel;
    }
}
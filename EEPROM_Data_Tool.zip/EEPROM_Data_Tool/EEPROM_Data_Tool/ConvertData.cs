﻿using System;
using System.Text;
using System.Windows.Forms;

namespace EEPROM_Data_Tool
{
    public class ConvertData
    {
        /*Convert hex string to byte array*/
        #region HexToByte
        public byte[] HexToByte(string msg)
        {
            string tempSting = null;
            //Remove any space from the string
            msg = msg.Replace(" ", "");
            //create a byte array the length of thestring divide by 2
            byte[] comBuffer = new byte[(msg.Length / 2) + (msg.Length % 2)];
            // Loop through the length of the provide string
            for (int i = 0; i < msg.Length; i += 2)
            {
                //convert each set of 2 character to a byte and add to the array
                try
                {
                    try
                    {
                        tempSting = msg.Substring(i, 2);  //Sub string 2 char
                    }
                    catch
                    {
                        // msg is odd (12 34 5) -> add 0 at last digit (12 34 05)
                        msg = msg.Insert(i, "0");
                        tempSting = msg.Substring(i, 2);
                    }
                    //convert sting to byte
                    comBuffer[i / 2] = (byte)Convert.ToByte(tempSting, 16);  // 16 = Base
                    //comBuffer[i / 2] = (byte)Convert.ToByte(msg.Substring(i, 2), 16);  // 16 = Base
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Incorrect input format! : " + ex.Message, "Status",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                }
            }

            return comBuffer;

        }
        #endregion

        #region IntToBinString
        public string IntToBinString(int n)
        {
            char[] b = new char[32];
            int pos = 31;
            int i = 0;

            while (i < 32)
            {
                if ((n & (1 << i)) != 0)
                    b[pos] = '1';
                else
                    b[pos] = '0';
                pos--;
                i++;
            }
            return new string(b);
        }
        #endregion

        /*Convert string to hex*/
        #region StringToHex
        public string StringToAsciiString(string hexstring)
        {
            var sb = new StringBuilder();
            foreach (char t in hexstring)
                sb.Append(Convert.ToInt32(t).ToString("x") + " ");
            return sb.ToString();
        }
        #endregion

        #region ByteToHex
        public string ByteToHexString(byte[] comByte)
        {
            //create a new StringBuilder object
            StringBuilder builder = new StringBuilder(comByte.Length * 3);
            //loop through each byte in the array
            foreach (byte data in comByte)
                //convert the byte to a string and add to the stringbuilder
                //builder.Append(Convert.ToString(data, 16).PadLeft(2, '0').PadRight(3, ' '));
                builder.Append(Convert.ToString(data, 16).PadLeft(2, '0'));
            //return the converted value
            return builder.ToString().ToUpper();
        }

        public byte[] StringToBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        #region HexToInt
        // <summary>
        /// Convert hex data to integer
        /// </summary>
        public int HexToInt(char c)
        {
            int first = c / 16 - 3;
            int second = c % 16;
            int result = first * 10 + second;
            if (result > 9) result--;
            return (result);
        }
        #endregion

        #region HexToAscii
        // <summary>
        /// Convert hex data to Ascii int
        /// </summary>
        public int HexToAscii(char c, char d)
        {
            int high = HexToInt(c) * 16;
            int low = HexToInt(d);
            return (high + low);
        }
        #endregion

        #endregion /*Convert Data*/

        // <summary>
        /// Returns a string containing a specified number of characters from the right side of a string.
        /// </summary>
        public string GetRight(string value, int length)
        {
            string result = value;
            if (value != null)
                result = value.Substring(0, Math.Max(value.Length, length));
            return result;
        }

        public string TakeLast(string input, int num)
        {
            if (num > input.Length)
            {
                num = input.Length;
            }
            return input.Substring(input.Length - num);
        }

        #region BitOperant
        /// <summary>
        /// Convert byte<8bit> to Uint16<16bit>
        /// <param name="></param>
        /// input : <byte>B0,B1 
        /// output : <uint16> U16
        /// 2019-03-29 First written by S.Pairot
        /// <summary>
        public UInt16 Byte2UInt16(byte B0, byte B1)
        {
            UInt16 U16;
            U16 = (UInt16)(B0 & 0x00FF);           // Low byte
            U16 |= (UInt16)((B1 << 8) & 0xFF00);   // Hi byte
            return U16;
        }
        /// <summary>
        /// Get lower/upper bit
        /// <param name="></param>
        /// input : <string>type "Hi"/"Lo", <byte>data 
        /// output : <uint16> data
        /// 2019-03-29 First written by S.Pairot
        /// <summary>
        public byte GetLowerUpperBit(string type, byte data)
        {
            byte L_data;
            if (type == "Lo") L_data = (byte)(data & 0x0F);
            else L_data = (byte)((data >> 4) & 0x0F);

            return L_data;
        }
        #endregion

        /// <summary>
        /// check specify bit set
        /// <param name="></param>
        /// input : <byte>data, <byte>bit 
        /// output : <bool> true/false
        /// 2019-03-29 First written by S.Pairot
        /// <summary>
        public byte ChkBit(byte data, byte bit)
        {
            byte L_set = 0;
            if (((data >> bit) & 0x01) == 0x01) L_set = 1;
            return L_set;
        }
    }
}

﻿namespace EEPROM_Data_Tool
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlMenuLeft = new System.Windows.Forms.Panel();
            this.btnNotification = new System.Windows.Forms.Button();
            this.pnlCursor = new System.Windows.Forms.Panel();
            this.btnEmail = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblcopyright = new System.Windows.Forms.Label();
            this.btnAdmin = new System.Windows.Forms.Button();
            this.lbltctc = new System.Windows.Forms.Label();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnTool = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.lblLogo = new System.Windows.Forms.Label();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnResetResult = new System.Windows.Forms.Button();
            this.cboFile = new System.Windows.Forms.ComboBox();
            this.btnCloseChildForm = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnHideMenu = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnLoadTemplate = new System.Windows.Forms.Button();
            this.btnVerifyData = new System.Windows.Forms.Button();
            this.pnlSubMenuTool = new System.Windows.Forms.Panel();
            this.btnOpenHex = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.aNSIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNTELToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStriplblUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.fileSizeToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.bitToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelEECode = new System.Windows.Forms.ToolStripStatusLabel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlSubMenuExport = new System.Windows.Forms.Panel();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnExportHex = new System.Windows.Forms.Button();
            this.metroTabControl = new MetroFramework.Controls.MetroTabControl();
            this.mtTabHex = new MetroFramework.Controls.MetroTabPage();
            this.hexBox = new Be.Windows.Forms.HexBox();
            this.mtTabTemplate = new MetroFramework.Controls.MetroTabPage();
            this.dataGridViewTmplate = new System.Windows.Forms.DataGridView();
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.pnlMenuLeft.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlSubMenuTool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.StatusStrip.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlSubMenuExport.SuspendLayout();
            this.metroTabControl.SuspendLayout();
            this.mtTabHex.SuspendLayout();
            this.mtTabTemplate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTmplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenuLeft
            // 
            this.pnlMenuLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnlMenuLeft.Controls.Add(this.btnNotification);
            this.pnlMenuLeft.Controls.Add(this.pnlCursor);
            this.pnlMenuLeft.Controls.Add(this.btnEmail);
            this.pnlMenuLeft.Controls.Add(this.btnLogout);
            this.pnlMenuLeft.Controls.Add(this.lblcopyright);
            this.pnlMenuLeft.Controls.Add(this.btnAdmin);
            this.pnlMenuLeft.Controls.Add(this.lbltctc);
            this.pnlMenuLeft.Controls.Add(this.btnExport);
            this.pnlMenuLeft.Controls.Add(this.btnTool);
            this.pnlMenuLeft.Controls.Add(this.btnSetting);
            this.pnlMenuLeft.Controls.Add(this.btnHome);
            this.pnlMenuLeft.Controls.Add(this.pnlLogo);
            this.pnlMenuLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuLeft.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMenuLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlMenuLeft.Name = "pnlMenuLeft";
            this.pnlMenuLeft.Size = new System.Drawing.Size(183, 853);
            this.pnlMenuLeft.TabIndex = 1;
            this.pnlMenuLeft.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // btnNotification
            // 
            this.btnNotification.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNotification.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNotification.BackgroundImage")));
            this.btnNotification.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNotification.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNotification.FlatAppearance.BorderSize = 0;
            this.btnNotification.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotification.Location = new System.Drawing.Point(29, 767);
            this.btnNotification.Margin = new System.Windows.Forms.Padding(4);
            this.btnNotification.Name = "btnNotification";
            this.btnNotification.Size = new System.Drawing.Size(35, 30);
            this.btnNotification.TabIndex = 19;
            this.btnNotification.UseVisualStyleBackColor = true;
            this.btnNotification.Click += new System.EventHandler(this.btnNotification_Click);
            // 
            // pnlCursor
            // 
            this.pnlCursor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlCursor.Location = new System.Drawing.Point(1, 75);
            this.pnlCursor.Name = "pnlCursor";
            this.pnlCursor.Size = new System.Drawing.Size(5, 60);
            this.pnlCursor.TabIndex = 1;
            // 
            // btnEmail
            // 
            this.btnEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnEmail.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEmail.BackgroundImage")));
            this.btnEmail.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmail.FlatAppearance.BorderSize = 0;
            this.btnEmail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmail.Location = new System.Drawing.Point(86, 767);
            this.btnEmail.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(36, 31);
            this.btnEmail.TabIndex = 18;
            this.btnEmail.UseVisualStyleBackColor = true;
            this.btnEmail.Click += new System.EventHandler(this.btnEmail_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.Image")));
            this.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.Location = new System.Drawing.Point(0, 375);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnLogout.Size = new System.Drawing.Size(183, 60);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "       Logout";
            this.toolTip1.SetToolTip(this.btnLogout, "Logout");
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            this.btnLogout.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // lblcopyright
            // 
            this.lblcopyright.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblcopyright.AutoSize = true;
            this.lblcopyright.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcopyright.ForeColor = System.Drawing.Color.White;
            this.lblcopyright.Location = new System.Drawing.Point(13, 825);
            this.lblcopyright.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblcopyright.Name = "lblcopyright";
            this.lblcopyright.Size = new System.Drawing.Size(150, 21);
            this.lblcopyright.TabIndex = 22;
            this.lblcopyright.Text = "Copyright © 2020";
            // 
            // btnAdmin
            // 
            this.btnAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdmin.FlatAppearance.BorderSize = 0;
            this.btnAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdmin.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdmin.ForeColor = System.Drawing.Color.White;
            this.btnAdmin.Image = ((System.Drawing.Image)(resources.GetObject("btnAdmin.Image")));
            this.btnAdmin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdmin.Location = new System.Drawing.Point(0, 315);
            this.btnAdmin.Name = "btnAdmin";
            this.btnAdmin.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnAdmin.Size = new System.Drawing.Size(183, 60);
            this.btnAdmin.TabIndex = 5;
            this.btnAdmin.Text = "    Admin";
            this.btnAdmin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnAdmin, "Admin");
            this.btnAdmin.UseVisualStyleBackColor = true;
            this.btnAdmin.Click += new System.EventHandler(this.btnAdmin_Click);
            this.btnAdmin.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // lbltctc
            // 
            this.lbltctc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbltctc.AutoSize = true;
            this.lbltctc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltctc.ForeColor = System.Drawing.Color.White;
            this.lbltctc.Location = new System.Drawing.Point(13, 802);
            this.lbltctc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbltctc.Name = "lbltctc";
            this.lbltctc.Size = new System.Drawing.Size(132, 21);
            this.lbltctc.TabIndex = 20;
            this.lbltctc.Text = "TCTC Software";
            // 
            // btnExport
            // 
            this.btnExport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExport.FlatAppearance.BorderSize = 0;
            this.btnExport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExport.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Image = ((System.Drawing.Image)(resources.GetObject("btnExport.Image")));
            this.btnExport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExport.Location = new System.Drawing.Point(0, 255);
            this.btnExport.Name = "btnExport";
            this.btnExport.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnExport.Size = new System.Drawing.Size(183, 60);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "    Export";
            this.btnExport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            this.btnExport.MouseHover += new System.EventHandler(this.btnExport_MouseHover);
            // 
            // btnTool
            // 
            this.btnTool.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTool.FlatAppearance.BorderSize = 0;
            this.btnTool.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTool.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTool.ForeColor = System.Drawing.Color.White;
            this.btnTool.Image = ((System.Drawing.Image)(resources.GetObject("btnTool.Image")));
            this.btnTool.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTool.Location = new System.Drawing.Point(0, 195);
            this.btnTool.Name = "btnTool";
            this.btnTool.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnTool.Size = new System.Drawing.Size(183, 60);
            this.btnTool.TabIndex = 3;
            this.btnTool.Text = "    Tool";
            this.btnTool.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTool.UseVisualStyleBackColor = true;
            this.btnTool.Click += new System.EventHandler(this.btnTool_Click);
            this.btnTool.MouseHover += new System.EventHandler(this.btnTool_MouseHover);
            // 
            // btnSetting
            // 
            this.btnSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetting.FlatAppearance.BorderSize = 0;
            this.btnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetting.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetting.ForeColor = System.Drawing.Color.White;
            this.btnSetting.Image = ((System.Drawing.Image)(resources.GetObject("btnSetting.Image")));
            this.btnSetting.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetting.Location = new System.Drawing.Point(0, 135);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnSetting.Size = new System.Drawing.Size(183, 60);
            this.btnSetting.TabIndex = 2;
            this.btnSetting.Text = "    Setting";
            this.btnSetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.btnSetting, "Setting");
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            this.btnSetting.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // btnHome
            // 
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 75);
            this.btnHome.Name = "btnHome";
            this.btnHome.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnHome.Size = new System.Drawing.Size(183, 60);
            this.btnHome.TabIndex = 1;
            this.btnHome.Text = "      Home";
            this.toolTip1.SetToolTip(this.btnHome, "Home");
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            this.btnHome.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // pnlLogo
            // 
            this.pnlLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.pnlLogo.Controls.Add(this.lblLogo);
            this.pnlLogo.Controls.Add(this.pictureBoxLogo);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(183, 75);
            this.pnlLogo.TabIndex = 0;
            this.pnlLogo.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.ForeColor = System.Drawing.Color.White;
            this.lblLogo.Location = new System.Drawing.Point(71, 29);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(112, 23);
            this.lblLogo.TabIndex = 1;
            this.lblLogo.Text = "EETool V1.0";
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.Location = new System.Drawing.Point(12, 15);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(47, 48);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.pnlTop.Controls.Add(this.btnResetResult);
            this.pnlTop.Controls.Add(this.cboFile);
            this.pnlTop.Controls.Add(this.btnCloseChildForm);
            this.pnlTop.Controls.Add(this.btnMinimize);
            this.pnlTop.Controls.Add(this.btnMaximize);
            this.pnlTop.Controls.Add(this.btnClose);
            this.pnlTop.Controls.Add(this.btnHideMenu);
            this.pnlTop.Controls.Add(this.lblTitle);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(183, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1049, 75);
            this.pnlTop.TabIndex = 4;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            this.pnlTop.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // btnResetResult
            // 
            this.btnResetResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResetResult.FlatAppearance.BorderSize = 0;
            this.btnResetResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResetResult.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetResult.ForeColor = System.Drawing.Color.White;
            this.btnResetResult.Image = ((System.Drawing.Image)(resources.GetObject("btnResetResult.Image")));
            this.btnResetResult.Location = new System.Drawing.Point(97, 20);
            this.btnResetResult.Name = "btnResetResult";
            this.btnResetResult.Size = new System.Drawing.Size(35, 35);
            this.btnResetResult.TabIndex = 27;
            this.toolTip1.SetToolTip(this.btnResetResult, "Clear verify result");
            this.btnResetResult.UseVisualStyleBackColor = true;
            this.btnResetResult.Click += new System.EventHandler(this.btnResetResult_Click);
            // 
            // cboFile
            // 
            this.cboFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(49)))), ((int)(((byte)(29)))));
            this.cboFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cboFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFile.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboFile.ForeColor = System.Drawing.SystemColors.Window;
            this.cboFile.FormattingEnabled = true;
            this.cboFile.Location = new System.Drawing.Point(165, 25);
            this.cboFile.Margin = new System.Windows.Forms.Padding(4);
            this.cboFile.Name = "cboFile";
            this.cboFile.Size = new System.Drawing.Size(217, 27);
            this.cboFile.TabIndex = 26;
            this.cboFile.SelectedIndexChanged += new System.EventHandler(this.cboFile_SelectedIndexChanged);
            // 
            // btnCloseChildForm
            // 
            this.btnCloseChildForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloseChildForm.FlatAppearance.BorderSize = 0;
            this.btnCloseChildForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseChildForm.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseChildForm.ForeColor = System.Drawing.Color.White;
            this.btnCloseChildForm.Image = ((System.Drawing.Image)(resources.GetObject("btnCloseChildForm.Image")));
            this.btnCloseChildForm.Location = new System.Drawing.Point(63, 24);
            this.btnCloseChildForm.Name = "btnCloseChildForm";
            this.btnCloseChildForm.Size = new System.Drawing.Size(25, 25);
            this.btnCloseChildForm.TabIndex = 25;
            this.toolTip1.SetToolTip(this.btnCloseChildForm, "Close sub window");
            this.btnCloseChildForm.UseVisualStyleBackColor = true;
            this.btnCloseChildForm.Click += new System.EventHandler(this.btnCloseChildForm_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimize.ForeColor = System.Drawing.Color.White;
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.Location = new System.Drawing.Point(935, 22);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(25, 25);
            this.btnMinimize.TabIndex = 24;
            this.btnMinimize.UseVisualStyleBackColor = true;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximize.FlatAppearance.BorderSize = 0;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaximize.ForeColor = System.Drawing.Color.White;
            this.btnMaximize.Image = ((System.Drawing.Image)(resources.GetObject("btnMaximize.Image")));
            this.btnMaximize.Location = new System.Drawing.Point(970, 22);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(25, 25);
            this.btnMaximize.TabIndex = 23;
            this.btnMaximize.UseVisualStyleBackColor = true;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(1002, 22);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(25, 25);
            this.btnClose.TabIndex = 22;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnHideMenu
            // 
            this.btnHideMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHideMenu.FlatAppearance.BorderSize = 0;
            this.btnHideMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHideMenu.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHideMenu.ForeColor = System.Drawing.Color.White;
            this.btnHideMenu.Image = ((System.Drawing.Image)(resources.GetObject("btnHideMenu.Image")));
            this.btnHideMenu.Location = new System.Drawing.Point(10, 19);
            this.btnHideMenu.Name = "btnHideMenu";
            this.btnHideMenu.Size = new System.Drawing.Size(35, 35);
            this.btnHideMenu.TabIndex = 2;
            this.btnHideMenu.UseVisualStyleBackColor = true;
            this.btnHideMenu.Click += new System.EventHandler(this.btnHideMenu_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(458, 25);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(69, 23);
            this.lblTitle.TabIndex = 21;
            this.lblTitle.Text = "Home";
            // 
            // btnLoadTemplate
            // 
            this.btnLoadTemplate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnLoadTemplate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoadTemplate.FlatAppearance.BorderSize = 0;
            this.btnLoadTemplate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadTemplate.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadTemplate.ForeColor = System.Drawing.Color.White;
            this.btnLoadTemplate.Image = ((System.Drawing.Image)(resources.GetObject("btnLoadTemplate.Image")));
            this.btnLoadTemplate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadTemplate.Location = new System.Drawing.Point(0, 0);
            this.btnLoadTemplate.Name = "btnLoadTemplate";
            this.btnLoadTemplate.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnLoadTemplate.Size = new System.Drawing.Size(210, 180);
            this.btnLoadTemplate.TabIndex = 4;
            this.btnLoadTemplate.Text = "  Open Template";
            this.btnLoadTemplate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLoadTemplate.UseVisualStyleBackColor = false;
            this.btnLoadTemplate.Click += new System.EventHandler(this.btnLoadTemplate_Click);
            // 
            // btnVerifyData
            // 
            this.btnVerifyData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnVerifyData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerifyData.FlatAppearance.BorderSize = 0;
            this.btnVerifyData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerifyData.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifyData.ForeColor = System.Drawing.Color.White;
            this.btnVerifyData.Image = ((System.Drawing.Image)(resources.GetObject("btnVerifyData.Image")));
            this.btnVerifyData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVerifyData.Location = new System.Drawing.Point(0, 120);
            this.btnVerifyData.Name = "btnVerifyData";
            this.btnVerifyData.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnVerifyData.Size = new System.Drawing.Size(210, 60);
            this.btnVerifyData.TabIndex = 5;
            this.btnVerifyData.Text = "  Start Verify";
            this.btnVerifyData.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnVerifyData.UseVisualStyleBackColor = false;
            this.btnVerifyData.Click += new System.EventHandler(this.btnVerifyData_Click);
            // 
            // pnlSubMenuTool
            // 
            this.pnlSubMenuTool.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnlSubMenuTool.Controls.Add(this.btnOpenHex);
            this.pnlSubMenuTool.Controls.Add(this.btnVerifyData);
            this.pnlSubMenuTool.Controls.Add(this.btnLoadTemplate);
            this.pnlSubMenuTool.Location = new System.Drawing.Point(183, 195);
            this.pnlSubMenuTool.Name = "pnlSubMenuTool";
            this.pnlSubMenuTool.Size = new System.Drawing.Size(210, 180);
            this.pnlSubMenuTool.TabIndex = 23;
            // 
            // btnOpenHex
            // 
            this.btnOpenHex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnOpenHex.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOpenHex.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnOpenHex.FlatAppearance.BorderSize = 0;
            this.btnOpenHex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenHex.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenHex.ForeColor = System.Drawing.Color.White;
            this.btnOpenHex.Image = ((System.Drawing.Image)(resources.GetObject("btnOpenHex.Image")));
            this.btnOpenHex.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenHex.Location = new System.Drawing.Point(0, 0);
            this.btnOpenHex.Name = "btnOpenHex";
            this.btnOpenHex.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnOpenHex.Size = new System.Drawing.Size(210, 60);
            this.btnOpenHex.TabIndex = 6;
            this.btnOpenHex.Text = "    Open Hex";
            this.btnOpenHex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnOpenHex.UseVisualStyleBackColor = false;
            this.btnOpenHex.Click += new System.EventHandler(this.btnOpenHex_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // StatusStrip
            // 
            this.StatusStrip.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton,
            this.ToolStripStatusLabel,
            this.toolStriplblUser,
            this.fileSizeToolStripStatusLabel,
            this.bitToolStripStatusLabel,
            this.toolStripStatusLabelEECode});
            this.StatusStrip.Location = new System.Drawing.Point(183, 827);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.Size = new System.Drawing.Size(1049, 26);
            this.StatusStrip.TabIndex = 25;
            this.StatusStrip.Text = "File";
            this.StatusStrip.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // toolStripDropDownButton
            // 
            this.toolStripDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aNSIToolStripMenuItem,
            this.iNTELToolStripMenuItem});
            this.toolStripDropDownButton.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripDropDownButton.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton.Image")));
            this.toolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton.Name = "toolStripDropDownButton";
            this.toolStripDropDownButton.Size = new System.Drawing.Size(59, 24);
            this.toolStripDropDownButton.Text = "INTEL";
            this.toolStripDropDownButton.ToolTipText = "Display format";
            // 
            // aNSIToolStripMenuItem
            // 
            this.aNSIToolStripMenuItem.Name = "aNSIToolStripMenuItem";
            this.aNSIToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.aNSIToolStripMenuItem.Text = "ANSI";
            this.aNSIToolStripMenuItem.Click += new System.EventHandler(this.aNSIToolStripMenuItem_Click);
            // 
            // iNTELToolStripMenuItem
            // 
            this.iNTELToolStripMenuItem.Name = "iNTELToolStripMenuItem";
            this.iNTELToolStripMenuItem.Size = new System.Drawing.Size(120, 26);
            this.iNTELToolStripMenuItem.Text = "INTEL";
            this.iNTELToolStripMenuItem.Click += new System.EventHandler(this.iNTELToolStripMenuItem_Click);
            // 
            // ToolStripStatusLabel
            // 
            this.ToolStripStatusLabel.Name = "ToolStripStatusLabel";
            this.ToolStripStatusLabel.Size = new System.Drawing.Size(0, 21);
            // 
            // toolStriplblUser
            // 
            this.toolStriplblUser.Name = "toolStriplblUser";
            this.toolStriplblUser.Size = new System.Drawing.Size(41, 21);
            this.toolStriplblUser.Text = "User";
            // 
            // fileSizeToolStripStatusLabel
            // 
            this.fileSizeToolStripStatusLabel.Name = "fileSizeToolStripStatusLabel";
            this.fileSizeToolStripStatusLabel.Size = new System.Drawing.Size(26, 21);
            this.fileSizeToolStripStatusLabel.Text = "Bit";
            // 
            // bitToolStripStatusLabel
            // 
            this.bitToolStripStatusLabel.Name = "bitToolStripStatusLabel";
            this.bitToolStripStatusLabel.Size = new System.Drawing.Size(34, 21);
            this.bitToolStripStatusLabel.Text = "Col";
            // 
            // toolStripStatusLabelEECode
            // 
            this.toolStripStatusLabelEECode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.toolStripStatusLabelEECode.Name = "toolStripStatusLabelEECode";
            this.toolStripStatusLabelEECode.Size = new System.Drawing.Size(51, 21);
            this.toolStripStatusLabelEECode.Text = "Code";
            // 
            // pnlContainer
            // 
            this.pnlContainer.Controls.Add(this.pnlSubMenuExport);
            this.pnlContainer.Controls.Add(this.metroTabControl);
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(0, 0);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(1232, 853);
            this.pnlContainer.TabIndex = 26;
            this.pnlContainer.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // pnlSubMenuExport
            // 
            this.pnlSubMenuExport.Controls.Add(this.btnExportExcel);
            this.pnlSubMenuExport.Controls.Add(this.btnExportHex);
            this.pnlSubMenuExport.Location = new System.Drawing.Point(183, 375);
            this.pnlSubMenuExport.Name = "pnlSubMenuExport";
            this.pnlSubMenuExport.Size = new System.Drawing.Size(210, 124);
            this.pnlSubMenuExport.TabIndex = 23;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnExportExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportExcel.FlatAppearance.BorderSize = 0;
            this.btnExportExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportExcel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportExcel.ForeColor = System.Drawing.Color.White;
            this.btnExportExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExportExcel.Image")));
            this.btnExportExcel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportExcel.Location = new System.Drawing.Point(0, 60);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnExportExcel.Size = new System.Drawing.Size(210, 60);
            this.btnExportExcel.TabIndex = 8;
            this.btnExportExcel.Text = "    Export Excel";
            this.btnExportExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportExcel.UseVisualStyleBackColor = false;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // btnExportHex
            // 
            this.btnExportHex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btnExportHex.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExportHex.FlatAppearance.BorderSize = 0;
            this.btnExportHex.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExportHex.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportHex.ForeColor = System.Drawing.Color.White;
            this.btnExportHex.Image = ((System.Drawing.Image)(resources.GetObject("btnExportHex.Image")));
            this.btnExportHex.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExportHex.Location = new System.Drawing.Point(0, 0);
            this.btnExportHex.Name = "btnExportHex";
            this.btnExportHex.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnExportHex.Size = new System.Drawing.Size(210, 60);
            this.btnExportHex.TabIndex = 7;
            this.btnExportHex.Text = "    Export Hex";
            this.btnExportHex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExportHex.UseVisualStyleBackColor = false;
            this.btnExportHex.Click += new System.EventHandler(this.btnExportHex_Click);
            // 
            // metroTabControl
            // 
            this.metroTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl.Controls.Add(this.mtTabHex);
            this.metroTabControl.Controls.Add(this.mtTabTemplate);
            this.metroTabControl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroTabControl.Location = new System.Drawing.Point(186, 75);
            this.metroTabControl.Name = "metroTabControl";
            this.metroTabControl.SelectedIndex = 0;
            this.metroTabControl.Size = new System.Drawing.Size(1043, 749);
            this.metroTabControl.TabIndex = 11;
            this.metroTabControl.UseSelectable = true;
            this.metroTabControl.SelectedIndexChanged += new System.EventHandler(this.metroTabControl_SelectedIndexChanged);
            this.metroTabControl.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // mtTabHex
            // 
            this.mtTabHex.BackColor = System.Drawing.Color.White;
            this.mtTabHex.Controls.Add(this.hexBox);
            this.mtTabHex.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtTabHex.HorizontalScrollbarBarColor = true;
            this.mtTabHex.HorizontalScrollbarHighlightOnWheel = false;
            this.mtTabHex.HorizontalScrollbarSize = 10;
            this.mtTabHex.Location = new System.Drawing.Point(4, 38);
            this.mtTabHex.Name = "mtTabHex";
            this.mtTabHex.Size = new System.Drawing.Size(1035, 707);
            this.mtTabHex.TabIndex = 0;
            this.mtTabHex.Text = "Hex";
            this.mtTabHex.VerticalScrollbarBarColor = true;
            this.mtTabHex.VerticalScrollbarHighlightOnWheel = false;
            this.mtTabHex.VerticalScrollbarSize = 10;
            // 
            // hexBox
            // 
            this.hexBox.AllowDrop = true;
            this.hexBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hexBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            // 
            // 
            // 
            this.hexBox.BuiltInContextMenu.CopyMenuItemText = "Copy ";
            this.hexBox.BuiltInContextMenu.CutMenuItemText = "Cut ";
            this.hexBox.BuiltInContextMenu.PasteMenuItemText = "Paste ";
            this.hexBox.BuiltInContextMenu.SelectAllMenuItemText = "Select All ";
            this.hexBox.ColumnInfoVisible = true;
            this.hexBox.Font = new System.Drawing.Font("Courier New", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hexBox.HexCasing = Be.Windows.Forms.HexCasing.Lower;
            this.hexBox.LineInfoVisible = true;
            this.hexBox.Location = new System.Drawing.Point(5, 4);
            this.hexBox.Margin = new System.Windows.Forms.Padding(0);
            this.hexBox.Name = "hexBox";
            this.hexBox.SelectionBackColor = System.Drawing.Color.LightSkyBlue;
            this.hexBox.ShadowSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(60)))), ((int)(((byte)(188)))), ((int)(((byte)(255)))));
            this.hexBox.Size = new System.Drawing.Size(962, 690);
            this.hexBox.StringViewVisible = true;
            this.hexBox.TabIndex = 11;
            this.hexBox.UseFixedBytesPerLine = true;
            this.hexBox.VScrollBarVisible = true;
            this.hexBox.CurrentLineChanged += new System.EventHandler(this.Position_Changed);
            this.hexBox.CurrentPositionInLineChanged += new System.EventHandler(this.Position_Changed);
            this.hexBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.hexBox_DragDrop);
            this.hexBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.hexBox_DragEnter);
            this.hexBox.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // mtTabTemplate
            // 
            this.mtTabTemplate.Controls.Add(this.dataGridViewTmplate);
            this.mtTabTemplate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mtTabTemplate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtTabTemplate.HorizontalScrollbarBarColor = true;
            this.mtTabTemplate.HorizontalScrollbarHighlightOnWheel = false;
            this.mtTabTemplate.HorizontalScrollbarSize = 10;
            this.mtTabTemplate.Location = new System.Drawing.Point(4, 38);
            this.mtTabTemplate.Name = "mtTabTemplate";
            this.mtTabTemplate.Size = new System.Drawing.Size(1035, 707);
            this.mtTabTemplate.TabIndex = 1;
            this.mtTabTemplate.Text = "Template";
            this.mtTabTemplate.VerticalScrollbarBarColor = true;
            this.mtTabTemplate.VerticalScrollbarHighlightOnWheel = false;
            this.mtTabTemplate.VerticalScrollbarSize = 10;
            // 
            // dataGridViewTmplate
            // 
            this.dataGridViewTmplate.AllowDrop = true;
            this.dataGridViewTmplate.AllowUserToAddRows = false;
            this.dataGridViewTmplate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewTmplate.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewTmplate.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewTmplate.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTmplate.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTmplate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTmplate.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTmplate.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewTmplate.Location = new System.Drawing.Point(3, 12);
            this.dataGridViewTmplate.Name = "dataGridViewTmplate";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTmplate.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTmplate.RowTemplate.Height = 24;
            this.dataGridViewTmplate.Size = new System.Drawing.Size(1027, 695);
            this.dataGridViewTmplate.TabIndex = 2;
            this.dataGridViewTmplate.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridViewTmplate_DragDrop);
            this.dataGridViewTmplate.DragEnter += new System.Windows.Forms.DragEventHandler(this.dataGridViewTmplate_DragEnter);
            this.dataGridViewTmplate.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1232, 853);
            this.Controls.Add(this.StatusStrip);
            this.Controls.Add(this.pnlSubMenuTool);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlMenuLeft);
            this.Controls.Add(this.pnlContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EEPROM Tool V1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.MouseHover += new System.EventHandler(this.btnHome_MouseHover);
            this.pnlMenuLeft.ResumeLayout(false);
            this.pnlMenuLeft.PerformLayout();
            this.pnlLogo.ResumeLayout(false);
            this.pnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlSubMenuTool.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlSubMenuExport.ResumeLayout(false);
            this.metroTabControl.ResumeLayout(false);
            this.mtTabHex.ResumeLayout(false);
            this.mtTabTemplate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTmplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenuLeft;
        private System.Windows.Forms.Button btnNotification;
        private System.Windows.Forms.Panel pnlCursor;
        private System.Windows.Forms.Button btnEmail;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblcopyright;
        private System.Windows.Forms.Button btnAdmin;
        private System.Windows.Forms.Label lbltctc;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnCloseChildForm;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnHideMenu;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel pnlSubMenuTool;
        private System.Windows.Forms.Button btnTool;
        private System.Windows.Forms.Button btnVerifyData;
        private System.Windows.Forms.Button btnLoadTemplate;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.ToolStripStatusLabel ToolStripStatusLabel;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem aNSIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNTELToolStripMenuItem;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.Button btnOpenHex;
        private System.Windows.Forms.ToolStripStatusLabel fileSizeToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel bitToolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStriplblUser;
        private MetroFramework.Controls.MetroTabControl metroTabControl;
        private MetroFramework.Controls.MetroTabPage mtTabHex;
        private MetroFramework.Controls.MetroTabPage mtTabTemplate;
        private Be.Windows.Forms.HexBox hexBox;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private System.Windows.Forms.ComboBox cboFile;
        private System.Windows.Forms.DataGridView dataGridViewTmplate;
        private System.Windows.Forms.Button btnResetResult;
        private System.Windows.Forms.Panel pnlSubMenuExport;
        private System.Windows.Forms.Button btnExportHex;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelEECode;
    }
}


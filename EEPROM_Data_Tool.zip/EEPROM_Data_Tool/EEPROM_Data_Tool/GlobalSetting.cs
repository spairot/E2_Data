﻿namespace EEPROM_Data_Tool
{
    public class Access
    {
        public readonly string[] Rule = {
            "BIT0",        // Bit 0
            "BIT1",        // Bit 1
            "BIT2",        // Bit 2
            "BIT3",        // Bit 3
            "BIT4",        // Bit 4
            "BIT5",        // Bit 5
            "BIT6",        // Bit 6
            "BIT7",        // Bit 7
            "BYTE",        // Byte
            "NIH",         // Bit 4 - Bit 7
            "NIL",         // Bit 0 - Bit 3
            "BITmn",       // Bit m - Bit n
        };
    }

    public class SettingData
    {
        public bool EditEnable { get; set; }   // Hex edit mode en/dis

        public int ThemeColor { get; set; }  // Display theme
        public int DispColor  { get; set; }  // Display color
    }

    /*Back up data class*/
    public class BackupData
    {
        // Hex edit
        public static bool EditEnable { get; set; }

        // Them color
        public static int ThemeColor { get; set; }  // Display theme
        public static int DispColor { get; set; }   // Display color
    }

    public class IntelBuf
    {
        public static byte[] byteDataIntel;
    }

    public class ModelInfo
    {
        public string ModelName { get; set; }
    }

}
